<template>
  <div class="container-fluid">
    <Sidenav />
    <Main />
  </div>
</template>

<script>
import Sidenav from "./components/Sidenav.vue";
import Main from "./components/Main.vue";

export default {
  name: "App",
  components: {
    Sidenav,
    Main,
  },
};
</script>

<style>
* {
  font-family: "Lato", sans-serif;
  margin: 0;
  padding: 0;
}
.container-fluid {
  display: flex;
  overflow-y: hidden;
  overflow-x: hidden;
}
</style>
