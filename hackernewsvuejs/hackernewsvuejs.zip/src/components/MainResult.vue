<template>
  <div class="main__result">
    <div class="main__result__top">
      <div class="category">
        <select name="categories" id="categories">
          <option value="popular">Popular</option>
          <option value="likes">Likes</option>
        </select>
      </div>
      <div class="filter">
        <select name="filter" id="filters">
          <option value="Filter">Filter</option>
        </select>
        <img
          src="@/assets/sort-button-with-three-lines.png"
          alt=""
          class="custom-arrow"
        />
      </div>
    </div>

    <MainResultView />
    <MainResultViewBottom />
  </div>
</template>

<script>
import MainResultView from "./MainResultView.vue";
import MainResultViewBottom from "./MainResultViewBottom.vue";
export default {
  name: "MainResult",
  components: {
    MainResultView,
    MainResultViewBottom,
  },
};
</script>

<style scoped>
.main__result {
  display: flex;
  flex-direction: column;
  width: 100%;
}
.main__result__top {
  display: flex;
  justify-content: space-between;
  margin-left: 2.5rem;
  margin-bottom: 0.5em;
}
.category select {
  background-color: rgb(241, 241, 241);
  padding: 6px;
  border: none;
  outline: none;
  border-radius: 5px;
  width: 110px;
}
.filter {
  margin-right: 2.5rem;
  background-color: rgb(241, 241, 241);
  border-right: none;
  border-radius: 5px;
  display: flex;
  position: relative;
  justify-content: center;
  align-items: center;
}
.filter select {
  padding: 6px;
  outline: none;
  border-radius: 5px;
  border: none;
  background-color: rgb(241, 241, 241);
  appearance: none;
  width: 110px;
  display: flex;
}
.custom-arrow {
  width: 15px;
  -webkit-transform: scaleX(-1);
  transform: scaleX(-1);
  position: absolute;
  top: 7px;
  right: 10px;
  display: block;
  pointer-events: none;
}
.main__result__bottom {
  display: flex;
  width: 95%;
  height: 6em;
  justify-content: space-between;
  align-items: center;
  margin-left: 2.3rem;
}
.main__result__bottom img {
  width: 20px;
}
.main__result__bottom img:nth-child(1) {
  opacity: 0.6;
}
.next__slide {
  display: flex;
  align-items: center;
}
#of__numbers__left {
  opacity: 0.5;
}
#of__results__span {
  opacity: 0.5;
  font-weight: 700;
}
#results__left,
#of {
  opacity: 0.9;
}
#theOf {
  font-weight: 500;
}

.leftSideResult__result {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 1rem 1rem 1rem 2.5rem;
}
.ResultImg {
  width: 50px;
  height: 50px;
}

.rightSideResult__result {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  width: 100%;
  border-top: 0px solid rgb(0, 0, 0, 0.3);
}

.Share,
.Bookmark {
  width: 1.5rem;
  height: 1.5rem;
  margin: 20px;
  opacity: 0.5;
}
.Share:hover,
.Bookmark:hover {
  opacity: 0.6;
}
</style>
