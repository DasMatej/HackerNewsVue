<template>
  <div class="middle">
    <div class="news" id="sideNavStyle">
      <img src="@/assets/news.png" alt="" />
      <span>News</span>
    </div>
    <div class="past" id="sideNavStyle">
      <img src="@/assets/document.png" alt="" />
      <span>Past</span>
    </div>
    <div class="comments" id="sideNavStyle">
      <img src="@/assets/conversation.png" alt="" />
      <span>Comments</span>
    </div>
    <div class="show" id="sideNavStyle">
      <img src="@/assets/witness.png" alt="" />
      <span>Show</span>
    </div>
    <div class="jobs" id="sideNavStyle">
      <img src="@/assets/search.png" alt="" />
      <span>Jobs</span>
    </div>
    <div class="ask" id="sideNavStyle">
      <img src="@/assets/question.png" alt="" />
      <span>Ask</span>
    </div>
  </div>
</template>
<script>
export default {
  name: "SidenavMiddle",
};
</script>

<style scoped>
.middle {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: auto;
}
.middle div {
  display: flex;
  width: 200px;
  height: 3vh;
  margin: 10px 10px 10px -20px;
  padding: 1.5rem;
  align-items: center;
  font-weight: 900;
  font-size: larger;
}
.middle div a {
  display: flex;
  justify-content: center;
  align-items: center;
  text-decoration: none;
}
.middle div a {
  color: black;
}
.middle div a span {
  font-size: 2.5vh;
}
.news {
  background-color: white;
}
.middle div:nth-child(n + 2):nth-child(-n + 6) {
  opacity: 0.6;
}
.middle div:hover {
  background-color: white;
}
.middle img {
  width: 4vh;
  margin-right: 30px;
}
</style>
