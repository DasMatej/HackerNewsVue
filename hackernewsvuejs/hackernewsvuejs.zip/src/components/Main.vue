<template>
  <div class="main">
    <MainHeader />
    <MainTrending />
    <MainResult />
  </div>
</template>

<script>
import MainHeader from "./MainHeader.vue";
import MainTrending from "./MainTrending.vue";
import MainResult from "./MainResult.vue";

export default {
  name: "Main",
  components: {
    MainHeader,
    MainTrending,
    MainResult,
  },
};
</script>

<style scoped>
.main {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100vh;
}
</style>
