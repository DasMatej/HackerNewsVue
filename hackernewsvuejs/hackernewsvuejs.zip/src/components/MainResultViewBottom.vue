<template>
  <div class="main__result__bottom">
    <div class="next__slide">
      <img
        src="@/assets/left-chevron.png"
        @click="this.pageNumber > 1 ? pagesNumbersMinus() : this.pageNumber"
        id="left__arrow"
      />
      <span class="numbers__left">
        <span id="start__numbers">{{ this.pageNumber }}</span>
        <span id="of__numbers__left"> /</span>
        <span id="of__numbers__left"> 83</span>
      </span>
      <img
        src="@/assets/chevron.png"
        @click="this.pageNumber < 83 ? pagesNumbersPlus() : this.pageNumber"
        id="right__arrow"
      />
    </div>
    <div class="of__results">
      <span id="of__results__span">
        <span id="of"> {{ this.pagesShow }} </span>
        <span id="theOf"> of </span>
        <span id="results__left"> 498 </span>
        <span>resulsts</span>
      </span>
    </div>
  </div>
</template>

<script>
export default {
  name: "MainResultViewBottom",
  data() {
    return {
      pageNumber: 1,
      pagesShow: 6,
    };
  },
  methods: {
    pagesNumbersPlus() {
      this.pageNumber++;
      this.pagesShow += 6;
    },
    pagesNumbersMinus() {
      this.pageNumber--;
      this.pagesShow -= 6;
    },
  },
};
</script>

<style scoped>
.main__result__bottom {
  display: flex;
  width: 95%;
  height: 6em;
  justify-content: space-between;
  align-items: center;
  margin-left: 2.3rem;
}
.main__result__bottom img {
  width: 20px;
}
.main__result__bottom img:nth-child(1) {
  opacity: 0.6;
}
.next__slide {
  display: flex;
  align-items: center;
}
#of__numbers__left {
  opacity: 0.5;
}
#of__results__span {
  opacity: 0.5;
  font-weight: 700;
}
#results__left,
#of {
  opacity: 0.9;
}
#theOf {
  font-weight: 500;
}
</style>
