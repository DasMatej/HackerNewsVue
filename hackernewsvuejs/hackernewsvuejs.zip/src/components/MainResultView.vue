<template>
  <div class="result">
    <!-- <button @click="isHackerNewsApi">Test</button> -->
    <div class="result__for" v-for="story in stories" :key="story.id">
      <!-- <div>{{ story.time | formatDate }} -->
      <div class="mainResult__result">
        <div class="leftSideResult__result">
          <img class="ResultImg" />
        </div>
        <!-- DataResult -->
        <div class="middleSideResult__result">
          <div class="dataResult">
            <div class="topResult__result">
              <div class="title__result">{{ story.title }}</div>
            </div>
            <div class="botResult__result">
              <div class="by__result">
                <img src="@/assets/user.png" class="UserImage" />{{ story.by }}
              </div>
              <div class="score__result">
                <img src="@/assets/like.png" class="Like" />{{ story.score }}
              </div>
              <div class="time__result">
                <img src="@/assets/time.png" class="Clock" />{{
                  convertTime(story.time)
                }}
                ago
              </div>
              <div class="kids__result">
                <img src="@/assets/speech-bubble.png" class="SpeechBubble" />
                {{ kidsNumber(story.kids) }}
              </div>
              <a class="url__result" :href="story.url">
                <img src="@/assets/globe.png" class="Globe" />{{
                  cutUrl(story.url)
                }}</a
              >
            </div>
          </div>
        </div>
        <div class="rightSideResult__result">
          <img src="@/assets/share.png" class="Share" />
          <img src="@/assets/bookmark.png" class="Bookmark" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { HackerNewsApi, User } from "../api/HackerNewsApi";
import { mapTime } from "../mapTime/mapTime";

export default {
  name: "MainResultView",
  mounted() {
    this.theStories = HackerNewsApi().getStories("topstories");
    // this.sotires = HackerNewsApi().getStories("topstories", 0);
    this.theStories.then((result) => {
      HackerNewsApi().getStory(result, this.page);
    });
    this.stories = User;
  },
  data() {
    return {
      id: "",
      by: "",
      kids: "",
      score: "",
      time: "",
      title: "",
      url: "",
      theStories: {},
      stories: [],
      page: 0,
    };
  },

  methods: {
    kidsNumber(comm) {
      if (comm) return comm.length;
      else return (comm = 0);
    },
    cutUrl(url) {
      return url
        .slice(8, url.length - 1)
        .split("/")
        .slice(0, 1)
        .join();
    },
    convertTime(time) {
      return mapTime(time);
    },
  },
};
</script>

<style scoped>
.result {
  display: flex;
  flex-direction: column;
  height: 33.5em;
  flex: 1;
}
.result__for {
}
.mainResult__result {
  display: flex;
  flex-direction: row;
  border-top: 1px solid rgb(0, 0, 0, 0.3);
}
.mainResult__result:nth-last-child(1) {
  border-bottom: 1px solid rgb(0, 0, 0, 0.3);
}
.middleSideResult__result {
  display: flex;
  flex: 0 0 80%;
}
.dataResult {
  display: flex;
  flex-direction: column;
  padding: 15px 0 15px 0;
  overflow: hidden;
  /* overflow:hidden  care*/
}
.topResult__result {
  display: flex;
  font-weight: 900;
  font-size: 20px;
  margin-bottom: 10px;
}
.botResult__result {
  display: flex;
  flex-direction: row;
}
.title__result {
  display: flex;
}
.UserImage,
.Like,
.Clock,
.SpeechBubble {
  width: 20px;
  opacity: 0.6;
  margin-right: 7px;
}
.Globe {
  width: 20px;
  margin-right: 7px;
}

.UserImage:hover,
.Like:hover,
.Clock:hover,
.SpeechBubble:hover,
.Globe:hover {
  opacity: 0.7;
}

.by__result,
.score__result,
.time__result,
.kids__result,
.url__result {
  display: flex;
  align-items: center;
}
.by__result {
  width: 9rem;
}
.score__result {
  width: 5rem;
}
.time__result {
  width: 10rem;
}
.kids__result {
  width: 9rem;
}
.url__result {
  width: 10.5rem;
}
.leftSideResult__result {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 1rem 1rem 1rem 2.5rem;
}
.ResultImg {
  width: 50px;
  height: 50px;
}

.rightSideResult__result {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  width: 100%;
  border-top: 0px solid rgb(0, 0, 0, 0.3);
}

.Share,
.Bookmark {
  width: 1.5rem;
  height: 1.5rem;
  margin: 20px;
  opacity: 0.5;
}
.Share:hover,
.Bookmark:hover {
  opacity: 0.6;
}
</style>
