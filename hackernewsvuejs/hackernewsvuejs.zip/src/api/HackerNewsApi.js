// import axios from "axios";

// import { hackerNewsApi } from "../../../../HackerNews/HackerNewsApi";

// var sixStories = [];
var User = [];

export var HackerNewsApi = function () {
  var me = {};
  var BASE_URL = "https://hacker-news.firebaseio.com/v0/";
  // var TopStories_URL = `${BASE_URL}topstories.json`;
  var storyUrl = `${BASE_URL}item/`;
  // var story = [];
  // var sixStories = [];

  me.fetchData = (url) => {
    return new Promise((resolve, reject) => {
      fetch(url)
        .then((res) => res.json())
        .then((data) => resolve(data))
        .catch((err) => reject(err));
    });
  };

  me.getStories = async (filter) => {
    return await HackerNewsApi().fetchData(`${BASE_URL}${filter}.json`);

    // data.slice(page * 6, (page + 1) * 6).map(async (d) => {
    //   let newsData = await HackerNewsApi().fetchData(`${storyUrl}${d}.json`);
    //   return newsData;
    // });
  };
  me.getStory = async (newsData, page) => {
    newsData.slice(page * 6, (page + 1) * 6).map(async (d) => {
      // console.log("TEst nad news");
      var news = await HackerNewsApi().fetchData(`${storyUrl}${d}.json`);
      // console.log(news);
      // console.log("pod news");
      User.push({
        id: news.id,
        by: news.by,
        kids: news.kids,
        score: news.score,
        time: news.time,
        title: news.title,
        url: news.url,
      });
      // console.log("Nad User");
      // console.log(User);
      // console.log("Pod User");
    });
  };

  // me.getStories = async function (filter, page) {
  //   await axios
  //     .get(`${BASE_URL}/${filter}.json`)
  //     .then((response) => {
  //       story = response.data;
  //       // console.log(story);
  //       story.slice(page * 6, (page + 1) * 6).map(async (d) => {
  //         await axios
  //           .get(`${storyUrl}${d}.json`)
  //           .then((res) => {
  //             // console.log(res.data);
  //             return {
  //               id: res.data.id,
  //               by: res.data.by,
  //               kids: res.data.kids,
  //               score: res.data.score,
  //               time: res.data.time,
  //               title: res.data.title,
  //               url: res.data.url,
  //             };
  //           })
  //           .catch((err) => console.log(err));
  //       });
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  //   // console.log(story);
  // };

  // console.log(story);
  // me.getSixStory = async function (theStory) {
  //   // console.log(theStory);
  //   theStory.slice(0, 6).map(async (d) => {
  //     await axios
  //       .get(`${storyUrl}${d}.json`)
  //       .then((res) => {
  //         User.by = res.data.by;
  //         User.id = res.data.id;
  //         // console.log(User);
  //         sixStories.push(User);
  //       })
  //       .catch((err) => {
  //         console.log(err);
  //       });
  //   });
  //   // console.log(sixStories);
  //   return sixStories;
  // };
  return me;
};
// console.log(User);
export { User };
// console.log(sixStories);
// export var HackerNewsApi = function () {
//   var me = {};
//   var BASE_URL = "https://hacker-news.firebaseio.com/v0/";
//   var TopStories_URL = `${BASE_URL}topstories.json`;
//   // var topCountStoriesUrl = `${BASE_URL}topstories.json?print=pretty&limitToFirst=150&orderBy="$key"`;
//   var storyUrl = `${BASE_URL}item/`;

//   me.fetchData = (url) => {
//     return new Promise((resolve, reject) => {
//       fetch(url)
//         .then((res) => res.json())
//         .then((data) => resolve(data))
//         .catch((err) => reject(err));
//     });
//   };

//   me.getStories = async () => {
//     var data = await HackerNewsApi().fetchData(TopStories_URL);
//     // console.log(data);
//     data.slice(0, 6).map(async (d) => {
//       var newsData = await HackerNewsApi().fetchData(`${storyUrl}${d}.json`);
//       console.log(newsData);
//     });
//   };
//   console.log("Test");
//   return me;
// };

/*
 *	api -> HackerNewsApi.js
 */
