/*
 *	api -> HackerNewsApi.js
 */
var HackerNewsApi = function () {
  var me = {};
  var BASE_URL = "hn...";
  var storie = [];

  me.getStories = async function (dateFilter, popularityFilter, page) {
    //
    return stories;
  };

  return me;
};

/*
 *	models -> story.js
 */
var Story = function () {
  var me = {};

  me.title = null;
  me.text = null;
  me.publishDate = null;
  me.tags = [];

  return me;
};

/*
 *	models -> date.filter.js
 */
var DateFilter = {
  Dayly: "24h",
  Weekly: "7d",
  Monthly: "1m",
};

/*
 *	models -> popularity.filter.js
 */
var PopularityFilter = {
  New: "New",
  Popular: "Popular",
};

/*
 *	component -> stories.js
 */
var client = new HackerNewsApi();
var stories = client.getStories(DateFilter.Daily, PopularityFilter.New);
render(stories);
